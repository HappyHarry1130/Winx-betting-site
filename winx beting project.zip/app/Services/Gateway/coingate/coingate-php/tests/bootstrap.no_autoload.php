<?php

require_once __DIR__ . '/TestCase.php';
require_once __DIR__ . '/../init.php';
