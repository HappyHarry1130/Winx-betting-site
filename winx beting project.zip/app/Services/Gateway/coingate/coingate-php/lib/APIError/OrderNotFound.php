<?php

namespace CoinGate\APIError;

# HTTP Status 404
class OrderNotFound extends NotFound
{
}

